import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, X, Heart, MapPin } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useCart } from '../hooks/useCart';

interface HeaderProps {
  onSearch: (query: string) => void;
  onCategoryFilter: (category: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch, onCategoryFilter }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isLoginOpen, setIsLoginOpen, login, logout } = useAuth();
  const { setIsOpen: setCartOpen, getTotalItems } = useCart();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const LoginModal = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = (e: React.FormEvent) => {
      e.preventDefault();
      login(email, password);
    };

    if (!isLoginOpen) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Login</h2>
            <button onClick={() => setIsLoginOpen(false)}>
              <X className="w-5 h-5" />
            </button>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2 border rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-2 border rounded-md"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    );
  };

  return (
    <>
      <header className="bg-blue-600 text-white shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-white rounded-md flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">F</span>
                </div>
                <span className="text-xl font-bold">Flipkart</span>
              </div>
              <div className="hidden lg:flex items-center text-sm">
                <span className="italic">Explore</span>
                <span className="ml-1 text-yellow-300">Plus</span>
              </div>
            </div>

            <div className="flex-1 max-w-2xl mx-4">
              <form onSubmit={handleSearch} className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for products, brands and more"
                  className="w-full px-4 py-2 pr-12 text-gray-800 rounded-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
                <button
                  type="submit"
                  className="absolute right-0 top-0 h-full px-4 bg-yellow-500 text-blue-900 rounded-r-sm hover:bg-yellow-400 transition-colors"
                >
                  <Search className="w-5 h-5" />
                </button>
              </form>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-6">
                <div className="flex items-center space-x-1 cursor-pointer hover:bg-blue-700 px-3 py-2 rounded">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">Deliver to</span>
                </div>
                
                {user ? (
                  <div className="flex items-center space-x-2 cursor-pointer hover:bg-blue-700 px-3 py-2 rounded">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-6 h-6 rounded-full"
                    />
                    <span className="text-sm">{user.name}</span>
                    <button
                      onClick={logout}
                      className="text-xs bg-blue-700 px-2 py-1 rounded hover:bg-blue-800"
                    >
                      Logout
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsLoginOpen(true)}
                    className="flex items-center space-x-1 cursor-pointer hover:bg-blue-700 px-3 py-2 rounded"
                  >
                    <User className="w-4 h-4" />
                    <span className="text-sm">Login</span>
                  </button>
                )}

                <div className="flex items-center space-x-1 cursor-pointer hover:bg-blue-700 px-3 py-2 rounded">
                  <Heart className="w-4 h-4" />
                  <span className="text-sm">Wishlist</span>
                </div>

                <button
                  onClick={() => setCartOpen(true)}
                  className="flex items-center space-x-1 cursor-pointer hover:bg-blue-700 px-3 py-2 rounded relative"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span className="text-sm">Cart</span>
                  {getTotalItems() > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {getTotalItems()}
                    </span>
                  )}
                </button>
              </div>

              <button
                className="md:hidden p-2 hover:bg-blue-700 rounded"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden bg-blue-700 border-t border-blue-500">
            <div className="container mx-auto px-4 py-4 space-y-4">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Account</span>
              </div>
              <div className="flex items-center space-x-2">
                <Heart className="w-4 h-4" />
                <span>Wishlist</span>
              </div>
              <button
                onClick={() => setCartOpen(true)}
                className="flex items-center space-x-2 w-full"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Cart ({getTotalItems()})</span>
              </button>
            </div>
          </div>
        )}
      </header>

      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-8 h-12 overflow-x-auto">
            <button
              onClick={() => onCategoryFilter('')}
              className="whitespace-nowrap text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              All
            </button>
            <button
              onClick={() => onCategoryFilter('Electronics')}
              className="whitespace-nowrap text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Electronics
            </button>
            <button
              onClick={() => onCategoryFilter('Fashion')}
              className="whitespace-nowrap text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Fashion
            </button>
            <button
              onClick={() => onCategoryFilter('Home & Kitchen')}
              className="whitespace-nowrap text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Home & Kitchen
            </button>
            <button
              onClick={() => onCategoryFilter('Books')}
              className="whitespace-nowrap text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Books
            </button>
            <button
              onClick={() => onCategoryFilter('Sports')}
              className="whitespace-nowrap text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Sports
            </button>
          </div>
        </div>
      </div>

      <LoginModal />
    </>
  );
};

export default Header;