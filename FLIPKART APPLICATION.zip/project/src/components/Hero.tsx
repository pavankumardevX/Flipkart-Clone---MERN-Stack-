import React from 'react';
import { ChevronRight, Zap, Truck, Shield, Headphones } from 'lucide-react';

const Hero: React.FC = () => {
  const offers = [
    {
      title: "iPhone 15 Series",
      subtitle: "Starting from ₹79,900",
      image: "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=600",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      title: "Samsung Galaxy S24",
      subtitle: "Up to ₹20,000 off",
      image: "https://images.pexels.com/photos/1482476/pexels-photo-1482476.jpeg?auto=compress&cs=tinysrgb&w=600",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      title: "Fashion Week Sale",
      subtitle: "50-80% off",
      image: "https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=600",
      gradient: "from-orange-500 to-red-500"
    }
  ];

  const features = [
    {
      icon: <Zap className="w-5 h-5" />,
      title: "Plus",
      subtitle: "Fast Delivery"
    },
    {
      icon: <Truck className="w-5 h-5" />,
      title: "Free Delivery",
      subtitle: "On orders above ₹499"
    },
    {
      icon: <Shield className="w-5 h-5" />,
      title: "100% Safe",
      subtitle: "Secure payments"
    },
    {
      icon: <Headphones className="w-5 h-5" />,
      title: "24/7 Support",
      subtitle: "Customer care"
    }
  ];

  return (
    <div className="bg-gradient-to-br from-blue-50 via-white to-orange-50">
      {/* Main Hero Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {offers.map((offer, index) => (
            <div
              key={index}
              className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${offer.gradient} text-white p-6 cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl`}
            >
              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-2">{offer.title}</h3>
                <p className="text-sm opacity-90 mb-4">{offer.subtitle}</p>
                <div className="flex items-center space-x-1 text-sm font-medium">
                  <span>Shop Now</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
              <div className="absolute -right-4 -bottom-4 w-32 h-32 opacity-20">
                <img
                  src={offer.image}
                  alt={offer.title}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Features Section */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                  {feature.icon}
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-gray-900">{feature.title}</h4>
                  <p className="text-xs text-gray-600">{feature.subtitle}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;