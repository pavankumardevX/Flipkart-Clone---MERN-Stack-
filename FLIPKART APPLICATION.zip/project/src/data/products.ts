import { Product, Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    icon: 'Smartphone',
    image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  {
    id: '2',
    name: 'Fashion',
    icon: 'Shirt',
    image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  {
    id: '3',
    name: 'Home & Kitchen',
    icon: 'Home',
    image: 'https://images.pexels.com/photos/1080696/pexels-photo-1080696.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  {
    id: '4',
    name: 'Books',
    icon: 'BookOpen',
    image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  {
    id: '5',
    name: 'Sports',
    icon: 'Dumbbell',
    image: 'https://images.pexels.com/photos/116077/pexels-photo-116077.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  {
    id: '6',
    name: 'Beauty',
    icon: 'Sparkles',
    image: 'https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=300'
  }
];

export const products: Product[] = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max',
    price: 134900,
    originalPrice: 159900,
    discount: 16,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 24580,
    category: 'Electronics',
    description: 'The most advanced iPhone ever with titanium design and Action Button.',
    features: ['A17 Pro chip', '48MP camera system', 'Titanium design', 'Action Button'],
    inStock: true,
    fastDelivery: true
  },
  {
    id: '2',
    name: 'Samsung Galaxy S24 Ultra',
    price: 124999,
    originalPrice: 139999,
    discount: 11,
    image: 'https://images.pexels.com/photos/1482476/pexels-photo-1482476.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 18420,
    category: 'Electronics',
    description: 'Galaxy AI is here. Search like never before, get real-time interpretation on a call, format your notes into a clear summary, and effortlessly edit your photos.',
    features: ['200MP camera', 'S Pen included', 'Galaxy AI', '5000mAh battery'],
    inStock: true,
    fastDelivery: true
  },
  {
    id: '3',
    name: 'MacBook Air M3',
    price: 114900,
    originalPrice: 134900,
    discount: 15,
    image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.9,
    reviews: 12340,
    category: 'Electronics',
    description: 'Supercharged by M3 chip. Up to 18 hours of battery life. Liquid Retina display.',
    features: ['M3 chip', '8GB RAM', '256GB SSD', '18-hour battery'],
    inStock: true,
    fastDelivery: false
  },
  {
    id: '4',
    name: 'Nike Air Max 270',
    price: 12995,
    originalPrice: 16995,
    discount: 24,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 8920,
    category: 'Fashion',
    description: 'Nike Air Max 270 delivers visible cushioning under every step.',
    features: ['Air Max cushioning', 'Mesh upper', 'Rubber outsole', 'Lifestyle design'],
    inStock: true,
    fastDelivery: true
  },
  {
    id: '5',
    name: 'Adidas Ultraboost 22',
    price: 17999,
    originalPrice: 22999,
    discount: 22,
    image: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    reviews: 5670,
    category: 'Fashion',
    description: 'Made with a series of recycled materials, this upper features at least 50% recycled content.',
    features: ['Boost midsole', 'Primeknit upper', 'Continental rubber', 'Recycled materials'],
    inStock: true,
    fastDelivery: true
  },
  {
    id: '6',
    name: 'Sony WH-1000XM5',
    price: 29990,
    originalPrice: 34990,
    discount: 14,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 15670,
    category: 'Electronics',
    description: 'Industry-leading noise canceling with Dual Noise Sensor technology.',
    features: ['30-hour battery', 'Quick charge', 'Multipoint connection', 'Touch controls'],
    inStock: true,
    fastDelivery: true
  },
  {
    id: '7',
    name: 'Instant Pot Duo 7-in-1',
    price: 8999,
    originalPrice: 12999,
    discount: 31,
    image: 'https://images.pexels.com/photos/4226921/pexels-photo-4226921.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 22340,
    category: 'Home & Kitchen',
    description: '7-in-1 functionality: pressure cooker, slow cooker, rice cooker, steamer, sauté, yogurt maker, and warmer.',
    features: ['6-quart capacity', '14 smart programs', 'Stainless steel', 'Dishwasher safe'],
    inStock: true,
    fastDelivery: false
  },
  {
    id: '8',
    name: 'The Psychology of Money',
    price: 399,
    originalPrice: 599,
    discount: 33,
    image: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.9,
    reviews: 45670,
    category: 'Books',
    description: 'Timeless lessons on wealth, greed, and happiness by Morgan Housel.',
    features: ['Bestseller', 'Paperback', '256 pages', 'English'],
    inStock: true,
    fastDelivery: true
  }
];